var hue = require("node-hue-api"),
    HueApi = hue.HueApi,
    lightState = hue.lightState;

var host = "10.0.0.20",
    username = "1g1FgNjQEos9ujcs6iS1FtBZAgEd06rALGnnlreb",
    api = new HueApi(host, username),
    state = lightState.create();

var app=require('express')();
var http=require('http').Server(app);
var awsIot = require('aws-iot-device-sdk');


var device = awsIot.device({
 keyPath: 'hue.private.key',
certPath: 'hue.cert.pem',
caPath: 'root-CA.crt',
clientId: 'hue',
region:'us-east-2',
host:'a3323f3h1lkxqc.iot.us-east-2.amazonaws.com'     
});


device
.on('connect', function() {
console.log('connect');
 device.publish('$aws/things/hue/shadow/get');
 device.subscribe('$aws/things/hue/shadow/get/accepted');
device.subscribe('$aws/things/hue/shadow/update/accepted');   
});
device
.on('message', function(topic, payload) {
//console.log('message', payload.toString());
        var json = JSON.parse(payload.toString());
    console.log(json.state.reported.red,json.state.reported.green,json.state.reported.blue);
   if(json.state.reported.stat == 1){
       api.setLightState(1, state.on()); 
   }
    else{
        api.setLightState(1,state.on()); 
    }
        api.setLightState(1, state.rgb(json.state.reported.red,json.state.reported.green,json.state.reported.blue));
        api.setLightState(1,state.brightness(json.state.reported.bri));
  
    
});


     

