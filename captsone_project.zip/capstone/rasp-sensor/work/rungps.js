    var SerialPort = require("serialport");
	var GPS = require('gps');
    var serialPort = new SerialPort("/dev/serial0", {
      baudrate: 9600,
	parser: SerialPort.parsers.readline('\n')
    });
    var gps = new GPS;
	
gps.on('data', function(data) {
  console.log("lattitude: "+gps.state.lat);
  console.log("longitude: "+gps.state.lon);
});
 
serialPort.on('data', function(data) {
  gps.update(data);
});