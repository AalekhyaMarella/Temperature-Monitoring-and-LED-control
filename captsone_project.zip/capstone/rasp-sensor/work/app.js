 var awsIot = require('aws-iot-device-sdk');
var sensor = require('node-dht-sensor');
var gpio = require('rpi-gpio');
var SerialPort = require("serialport");
var GPS = require('gps');
var MyEmitter = require('events');
var emitter = new MyEmitter();
emitter.setMaxListeners(100);
var tempt=0,temph=0;
var t,h,lat,lon;

var device = awsIot.device({
    keyPath: 'raspberry.private.key',
    certPath: 'raspberry.cert.pem',
    caPath: 'root-CA.crt',
    clientId: 'raspberry',
    region:'us-east-2',
    host:'a3323f3h1lkxqc.iot.us-east-2.amazonaws.com'      
});
var serialPort = new SerialPort("/dev/serial0", {
      baudrate: 9600,
	autoOpen: false,
	parser: SerialPort.parsers.readline('\n')
    });
var gps = new GPS;
device.on('connect', function() {
    console.log('connect');
    var myVar = setInterval(myTimer, 1000);  
});

function myTimer() {

    sensor.read(11, 18, function(err, temperature, humidity) {

        console.log('temp: ' + temperature.toFixed(3) + '°C, ' +'humidity: ' + humidity.toFixed(3) + '%');
        t= temperature;
        h=humidity;
        console.log(t);
    });
    if(serialPort.isOpen()==false){
        serialPort.open(function (err) {
    if (err) {
        return console.log('Error opening port: ', err.message);
    }
        });
    }

    serialPort.on('open', function() {
    gps.on('data', function(data) {
        lat=gps.state.lat; 
        lon=gps.state.lon;
    });
    serialPort.on('data', function(data) {
    gps.update(data);
    });

    });
    device.publish('$aws/things/mypc/shadow/update', JSON.stringify({ state:{reported:{
        Temperature:parseFloat(t),
        Humidity:h,
        lat:parseFloat(lat),
        long:parseFloat(lon)
    }} 
    }));
    console.log(lat,lon);
    if(serialPort.isOpen()){
        serialPort.close();
    }
    }

device.on('message', function(topic, payload) {
console.log('message', topic, payload.toString());
});